# AI Music Video Maker v0.4

This build combines two source-entry paths:
- Multiple YouTube URLs can be validated and added to a playlist.
- Multiple local videos can be selected through Android's gallery/document picker.
- Local video files can be paired with YouTube playlist entries.
- Media3 Transformer merges selected local video sources and saves MP4 to Movies/AIMusicVideoMaker.
- Local processing; no laptop server.

Important limitations:
- YouTube URLs are playlist references only. This build does not download or extract YouTube streams.
- Render requires local video files the user owns or is authorized to process.
- The current renderer merges video files only. It does not yet render audio-only tracks into a still-image music video.
- 720p normalization, title-card overlay, karaoke word timing, local AI music generation, beat analysis, and local AI image generation are not implemented yet.
- The title field is currently a project field and is not burned into the output.

Build using the included GitHub Actions workflow (JDK 17, Gradle 8.9).
