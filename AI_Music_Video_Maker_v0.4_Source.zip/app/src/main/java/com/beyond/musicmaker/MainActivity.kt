package com.beyond.musicmaker

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import java.io.File

data class PlaylistEntry(val url: String, var sourceUri: Uri? = null)

class MainActivity : AppCompatActivity() {
    private val playlist = mutableListOf<PlaylistEntry>()
    private lateinit var urlInput: EditText
    private lateinit var listText: TextView
    private lateinit var titleInput: EditText
    private lateinit var lyricsInput: EditText
    private lateinit var status: TextView
    private lateinit var addButton: Button
    private lateinit var attachButton: Button
    private lateinit var renderButton: Button

    private val videoPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
            }
            val pending = playlist.filter { it.sourceUri == null }
            uris.forEachIndexed { index, uri ->
                if (index < pending.size) pending[index].sourceUri = uri
            }
            refreshList()
            val attached = playlist.count { it.sourceUri != null }
            status.text = "$attached dari ${playlist.size} link sudah dipasangkan dengan file lokal."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11,16,32)
        window.navigationBarColor = android.graphics.Color.rgb(11,16,32)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20))
            setBackgroundColor(android.graphics.Color.rgb(11,16,32))
        }
        val scroll = ScrollView(this).apply { addView(page) }

        page.addView(label("♪  AI MUSIC VIDEO MAKER", 21, "#FFFFFF", true))
        page.addView(label("MULTI SOURCE • LOCAL PROCESSING", 10, "#A998FF", true))
        page.addView(label("Susun link video\nmenjadi satu playlist.", 28, "#FFFFFF", true).apply {
            setPadding(0, dp(25), 0, dp(8))
        })
        page.addView(label(
            "Tempel beberapa URL YouTube. Untuk pemrosesan, pasangkan setiap link dengan file video lokal yang Anda miliki atau berhak gunakan.",
            13, "#AAB5D0", false
        ))

        page.addView(section("PILIHAN 1  •  LINK YOUTUBE"))
        urlInput = edit("Tempel URL YouTube, satu link per baris", multiline = true)
        page.addView(urlInput, params())
        addButton = button("TAMBAHKAN LINK KE PLAYLIST")
        addButton.setOnClickListener { addUrls() }
        page.addView(addButton, params())

        page.addView(section("PILIHAN 2  •  GALERI ANDROID"))
        val galleryButton = button("PILIH VIDEO DARI GALERI")
        galleryButton.setOnClickListener { videoPicker.launch(arrayOf("video/*")) }
        page.addView(galleryButton, params())
        page.addView(label("Pilih beberapa video sekaligus dari penyimpanan Android.", 11, "#AAB5D0", false))

        page.addView(section("ANTREAN / PLAYLIST"))
        listText = label("Belum ada link dalam playlist", 12, "#D7DDF0", false)
        page.addView(listText)
        attachButton = button("PILIH VIDEO GALERI UNTUK LINK YOUTUBE")
        attachButton.setOnClickListener {
            val missing = playlist.count { it.sourceUri == null }
            if (missing == 0) status.text = "Semua link sudah memiliki file lokal."
            else videoPicker.launch(arrayOf("video/*"))
        }
        page.addView(attachButton, params())
        val removeButton = button("HAPUS ITEM TERAKHIR")
        removeButton.setOnClickListener {
            if (playlist.isNotEmpty()) {
                playlist.removeAt(playlist.lastIndex)
                refreshList()
                status.text = "Item terakhir dihapus."
            }
        }
        page.addView(removeButton, params())
        val clearButton = button("KOSONGKAN PLAYLIST")
        clearButton.setOnClickListener {
            playlist.clear()
            urlInput.text.clear()
            refreshList()
            status.text = "Playlist dikosongkan."
        }
        page.addView(clearButton, params())

        page.addView(section("OPENING & LIRIK"))
        titleInput = edit("Judul yang tampil di opening saja")
        page.addView(titleInput, params())
        lyricsInput = edit("Tempel lirik resmi di sini (opsional)", multiline = true)
        page.addView(lyricsInput, params())
        page.addView(label(
            "Opening title dan sinkronisasi karaoke per kata belum dirender pada build ini.",
            10, "#8996B3", false
        ))

        page.addView(section("RENDER LOKAL"))
        page.addView(label(
             "Output MP4. Video galeri diproses berurutan. Link YouTube hanya menjadi referensi playlist; aplikasi tidak mengunduh atau mengekstrak stream YouTube.",
            12, "#D7DDF0", false
        ))
        renderButton = button("GABUNGKAN VIDEO GALERI")
        renderButton.setOnClickListener { startMerge() }
        page.addView(renderButton, params())

        status = label(
             "Mode lokal: tanpa server laptop. Pilih link YouTube sebagai referensi atau impor video dari galeri.",
            12, "#A998FF", false
        )
        page.addView(status)
        page.addView(label(
             "Belum aktif: metadata YouTube, title card, karaoke word-timing, AI music, analisis beat, dan AI image generator lokal.",
            10, "#77839E", false
        ).apply { setPadding(0, dp(22), 0, dp(25)) })
        setContentView(scroll)
    }

    private fun addUrls() {
        val lines = urlInput.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) {
            status.text = "Tempel minimal satu URL YouTube."
            return
        }
        var added = 0
        val invalid = mutableListOf<String>()
        lines.forEach { raw ->
            val uri = runCatching { Uri.parse(raw) }.getOrNull()
            val host = uri?.host?.lowercase().orEmpty()
            val valid = uri != null && uri.scheme in listOf("http", "https") &&
                (host == "youtu.be" || host == "youtube.com" ||
                 host.endsWith(".youtube.com") || host == "m.youtube.com")
            if (valid && playlist.none { it.url == raw }) {
                playlist.add(PlaylistEntry(raw))
                added++
            } else if (!valid) invalid.add(raw)
        }
        urlInput.text.clear()
        refreshList()
        status.text = "$added link ditambahkan. ${invalid.size} link tidak valid atau bukan URL YouTube."
    }

    private fun startMerge() {
        if (playlist.isEmpty()) {
            status.text = "Tambahkan URL YouTube ke playlist terlebih dahulu."
            return
        }
        val missing = playlist.count { it.sourceUri == null }
        if (missing > 0) {
            status.text = "Masih ada $missing link tanpa file video lokal. Pasangkan file sumber yang Anda berhak gunakan."
            return
        }
        renderButton.isEnabled = false
        addButton.isEnabled = false
        attachButton.isEnabled = false
        status.text = "Menyiapkan penggabungan ${playlist.size} video..."
        try {
            val items = playlist.mapNotNull { it.sourceUri }.map { uri ->
                EditedMediaItem.Builder(MediaItem.fromUri(uri)).build()
            }
            val sequence = EditedMediaItemSequence.Builder(items).build()
            val composition = Composition.Builder(sequence).build()
            val outFile = File(cacheDir, "music_video_${System.currentTimeMillis()}.mp4")
            val transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        saveToGallery(outFile)
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        runOnUiThread {
                            status.text = "Render gagal: ${exportException.message ?: "format video tidak didukung"}"
                            setButtons(true)
                        }
                    }
                }).build()
            transformer.start(composition, outFile.absolutePath)
        } catch (e: Exception) {
            status.text = "Tidak dapat memulai render: ${e.message}"
            setButtons(true)
        }
    }

    private fun saveToGallery(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "AI_Music_Video_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIMusicVideoMaker")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file output")
            contentResolver.openOutputStream(uri)?.use { output ->
                file.inputStream().use { it.copyTo(output) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            runOnUiThread {
                status.text = "Selesai. MP4 tersimpan di Movies/AIMusicVideoMaker. Video sumber digabung sesuai urutan playlist."
                setButtons(true)
            }
        } catch (e: Exception) {
            runOnUiThread {
                status.text = "Render selesai, tetapi gagal menyimpan ke galeri: ${e.message}"
                setButtons(true)
            }
        }
    }

    private fun setButtons(enabled: Boolean) {
        renderButton.isEnabled = enabled
        addButton.isEnabled = enabled
        attachButton.isEnabled = enabled
    }

    private fun refreshList() {
        listText.text = if (playlist.isEmpty()) "Belum ada link dalam playlist" else
            playlist.mapIndexed { i, entry ->
                val attached = if (entry.sourceUri != null) "✓ file dipasangkan" else "menunggu file lokal"
                "${i + 1}. ${entry.url}\n   $attached"
            }.joinToString("\n\n")
    }

    private fun section(s: String) = label(s, 12, "#A998FF", true).apply {
        setPadding(0, dp(22), 0, dp(9))
    }

    private fun label(s: String, size: Int, color: String, bold: Boolean) = TextView(this).apply {
        text = s
        textSize = size.toFloat()
        setTextColor(android.graphics.Color.parseColor(color))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun edit(hintText: String, multiline: Boolean = false) = EditText(this).apply {
        hint = hintText
        setTextColor(android.graphics.Color.WHITE)
        setHintTextColor(android.graphics.Color.GRAY)
        setPadding(dp(13))
        setBackgroundColor(android.graphics.Color.rgb(20,28,48))
        if (multiline) { minLines = 3; gravity = Gravity.TOP } else setSingleLine(true)
    }

    private fun button(s: String) = Button(this).apply {
        text = s
        isAllCaps = false
        setTextColor(android.graphics.Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(
            android.graphics.Color.rgb(118,89,237)
        )
    }

    private fun params() = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(7); bottomMargin = dp(7)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
