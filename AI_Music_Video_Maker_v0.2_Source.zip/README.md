# AI Music Video Maker Android — v0.2

Native Android prototype focused on local playlist merging.

## Implemented in this version
- Native Android UI.
- Select multiple local video files from Android storage.
- Merge selected videos sequentially using AndroidX Media3 Transformer.
- Save resulting MP4 to Movies/AIMusicVideoMaker.
- Java and Kotlin JVM targets both set to 17.

## Not implemented yet
- YouTube URL downloading/import. Only process files you own or are authorized to use.
- Reordering after selection (current order follows picker order).
- 720p scaling/normalization guarantee; source export behavior depends on input formats and Media3 support.
- Opening title card.
- Word-level karaoke timing/transcription.
- AI-generated 3D scenes based on lyrics.
- Dedicated music track replacement/mixing.

## Build
GitHub Actions workflow: `.github/workflows/android-apk.yml`.
Upload this project as repository contents (not as a nested ZIP), or use the workflow artifact pipeline supplied separately.
