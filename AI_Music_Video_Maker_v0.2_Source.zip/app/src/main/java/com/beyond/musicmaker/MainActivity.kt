package com.beyond.musicmaker

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import java.io.File

class MainActivity : AppCompatActivity() {
    private val clips = mutableListOf<Uri>()
    private lateinit var listText: TextView
    private lateinit var titleInput: EditText
    private lateinit var lyricsInput: EditText
    private lateinit var status: TextView
    private lateinit var addButton: Button
    private lateinit var renderButton: Button

    private val videoPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                clips.add(uri)
            }
            refreshList()
            status.text = "${clips.size} video masuk playlist."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11,16,32)
        window.navigationBarColor = android.graphics.Color.rgb(11,16,32)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20))
            setBackgroundColor(android.graphics.Color.rgb(11,16,32))
        }
        val scroll = ScrollView(this).apply { addView(page) }

        page.addView(label("♪  AI MUSIC VIDEO MAKER", 21, "#FFFFFF", true))
        page.addView(label("ANDROID STUDIO • LOCAL PROCESSING", 10, "#A998FF", true))
        page.addView(label("Gabungkan playlist video\nlangsung dari HP.", 28, "#FFFFFF", true).apply {
            setPadding(0, dp(25), 0, dp(8))
        })
        page.addView(label("Pilih beberapa file video lokal, atur urutan, lalu gabungkan menjadi satu MP4.", 13, "#AAB5D0", false))

        page.addView(section("01  •  PLAYLIST VIDEO"))
        addButton = button("＋  PILIH VIDEO DARI HP")
        addButton.setOnClickListener { videoPicker.launch(arrayOf("video/*")) }
        page.addView(addButton, params())
        listText = label("Belum ada video dipilih", 12, "#AAB5D0", false)
        page.addView(listText)
        val reorderInfo = label("Urutan mengikuti pilihan file. Hapus daftar untuk memilih ulang jika ingin mengubah urutan.", 10, "#8996B3", false)
        page.addView(reorderInfo)
        val clearButton = button("KOSONGKAN PLAYLIST")
        clearButton.setOnClickListener { clips.clear(); refreshList(); status.text = "Playlist dikosongkan." }
        page.addView(clearButton, params())

        page.addView(section("02  •  OPENING TITLE"))
        titleInput = edit("Judul yang tampil di awal video saja")
        page.addView(titleInput, params())
        page.addView(label("Catatan: title card belum dirender pada versi ini; kolom disiapkan untuk tahap berikutnya.", 10, "#8996B3", false))

        page.addView(section("03  •  LIRIK & KARAOKE"))
        lyricsInput = edit("Tempel lirik resmi di sini (opsional)", multiline = true)
        page.addView(lyricsInput, params())
        page.addView(label("Sinkronisasi karaoke per kata belum aktif. Lirik disimpan sebagai input spesifikasi untuk tahap alignment.", 10, "#8996B3", false))

        page.addView(section("04  •  OUTPUT"))
        page.addView(label("Target: MP4 • 720p (1280×720) • Visual AI 3D: tahap berikutnya • Audio video sumber dipertahankan.", 13, "#D7DDF0", false))
        renderButton = button("GABUNGKAN VIDEO")
        renderButton.setOnClickListener { startMerge() }
        page.addView(renderButton, params())

        status = label("Mode lokal: tidak membutuhkan server laptop. Pilih video yang Anda miliki atau berhak gunakan.", 12, "#A998FF", false)
        page.addView(status)
        page.addView(label("Versi 0.2: penggabungan video lokal. Generasi AI 3D, karaoke word-timing, title card, dan URL YouTube belum diimplementasikan.", 10, "#77839E", false).apply {
            setPadding(0, dp(22), 0, dp(25))
        })
        setContentView(scroll)
    }

    private fun startMerge() {
        if (clips.isEmpty()) {
            status.text = "Pilih minimal satu video terlebih dahulu."
            return
        }
        renderButton.isEnabled = false
        addButton.isEnabled = false
        status.text = "Menyiapkan penggabungan ${clips.size} video..."
        try {
            val items = clips.map { uri -> EditedMediaItem.Builder(MediaItem.fromUri(uri)).build() }
            val sequence = EditedMediaItemSequence.Builder(items).build()
            val composition = Composition.Builder(sequence).build()
            val outFile = File(cacheDir, "music_video_${System.currentTimeMillis()}.mp4")
            val transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        saveToGallery(outFile)
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        runOnUiThread {
                            status.text = "Render gagal: ${exportException.message ?: "format video tidak didukung"}"
                            renderButton.isEnabled = true
                            addButton.isEnabled = true
                        }
                    }
                }).build()
            transformer.start(composition, outFile.absolutePath)
        } catch (e: Exception) {
            status.text = "Tidak dapat memulai render: ${e.message}"
            renderButton.isEnabled = true
            addButton.isEnabled = true
        }
    }

    private fun saveToGallery(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "AI_Music_Video_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIMusicVideoMaker")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file output")
            contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            runOnUiThread {
                status.text = "Selesai. Video tersimpan di Movies/AIMusicVideoMaker. Render ini menggabungkan video sumber; belum menambahkan title/subtitle/AI visual."
                renderButton.isEnabled = true
                addButton.isEnabled = true
            }
        } catch (e: Exception) {
            runOnUiThread {
                status.text = "Video selesai dirender, tetapi gagal disimpan ke galeri: ${e.message}"
                renderButton.isEnabled = true
                addButton.isEnabled = true
            }
        }
    }

    private fun refreshList() {
        listText.text = if (clips.isEmpty()) "Belum ada video dipilih" else
            clips.mapIndexed { i, uri -> "${i + 1}. ${uri.lastPathSegment ?: "Video"}" }.joinToString("\n")
    }

    private fun section(s: String) = label(s, 12, "#A998FF", true).apply { setPadding(0, dp(22), 0, dp(9)) }
    private fun label(s: String, size: Int, color: String, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(android.graphics.Color.parseColor(color))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }
    private fun edit(hintText: String, multiline: Boolean = false) = EditText(this).apply {
        hint = hintText; setTextColor(android.graphics.Color.WHITE); setHintTextColor(android.graphics.Color.GRAY)
        setPadding(dp(13)); setBackgroundColor(android.graphics.Color.rgb(20,28,48))
        if (multiline) { minLines = 4; gravity = Gravity.TOP } else setSingleLine(true)
    }
    private fun button(s: String) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(android.graphics.Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.rgb(118,89,237))
    }
    private fun params() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7); bottomMargin = dp(7) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
